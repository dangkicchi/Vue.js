let app = new Vue({
	// options
  el: '#app',
  data: {
    message: 'Hello Vue.js!'
  },

  // data: {
  //   now: ''
  // },
  // methods: {
  //   onclick: function() {
  //     //alert('onclick!');
  //     this.now = new Date().toLocaleString();
  //   }
  // }

  // data: {
  // 	user: {
  //     firstName: 'Taro',
  //     lastName: 'Yamada',
  //     age: 28
  //   }
  // }

  // data: {
  //   colors: ['Red', 'Green', 'Blue']
  // }

  // data: {
  // 	toggle: true
  // }

  // data: {
  //   message: 'Hello Vue.js!'
  // }

  // data: {
  // 	message: 'Hello Vue.js!',
  //   count: 0,
  //   user: {
	//     	lastName: 'Yamada',
  // 	    firstName: 'Taro',
  //   	  prefecture: 'Tokyo'
  //     },
  //     colors: ['Red', 'Green', 'Blue']
  //   }
})

Vue.component('hello-component', {
  template: '<p>Hello!</p>'
})

let app = new Vue({
  el: '#app'
})
